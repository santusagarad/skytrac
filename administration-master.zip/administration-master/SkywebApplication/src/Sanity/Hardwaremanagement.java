package Sanity;

public class Hardwaremanagement {

}
